import { ethers } from "ethers";
import React, { useEffect, useState } from "react";
import "./App.css";
import abi from "./utils/BetPortal.json";

const App = () => {
  const [currentAccount, setCurrentAccount] = useState("");
  const contractAddress = "0x42526958AdD1D14ADd1EA66709E96d30F7DDaD34";
  const contractABI = abi.abi;

  const checkIfWalletIsConnected = async () => {
    try {
      const { ethereum } = window;

      if (!ethereum) {
        console.log("Make sure you have metamask!");
        return;
      } else {
        console.log("We have the ethereum object", ethereum);
      }

      const accounts = await ethereum.request({ method: "eth_accounts" });

      if (accounts.length !== 0) {
        const account = accounts[0];
        console.log("Found an authorized account:", account);
        setCurrentAccount(account);
      } else {
        console.log("No authorized account found");
      }
    } catch (error) {
      console.log(error);
    }
  }

  const connectWallet = async () => {
    try {
      const { ethereum } = window;

      if (!ethereum) {
        alert("Get MetaMask!");
        return;
      }

      const accounts = await ethereum.request({ method: "eth_requestAccounts" });

      console.log("Connected", accounts[0]);
      setCurrentAccount(accounts[0]);
    } catch (error) {
      console.log(error);
    }
  }

  const bet = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const betPortalContract = new ethers.Contract(contractAddress, contractABI, signer);

        let betCount = await betPortalContract.getBets();
        console.log("Retrieved total amount of bets...", betCount);
        let potSize = await betPortalContract.getPot();
        console.log("Retrieved pot size...", potSize.toString());

        /* Execute the actual bet from smart contract */
        let betGuess = document.getElementById("guess").value;
        let betAmount = document.getElementById("betAmount").value;

        console.log("Bet guess...", betGuess);
        console.log("Bet value added to the pot...", betAmount);
        const betTxn = await betPortalContract.bet(betGuess, 8, { gasLimit: 1000000, value: ethers.utils.parseEther(betAmount) });
        console.log("Mining...", betTxn.hash);

        await betTxn.wait();
        console.log("Mined -- ", betTxn.hash);

        betCount = await betPortalContract.getBets();
        console.log("Retrieved total amount of bets...", betCount);
        potSize = await betPortalContract.getPot();
        console.log("Retrieved pot size...", potSize.toString());

      } else {
        console.log("Ethereum object doesn't exist!");
      }
    } catch (error) {
      console.log(error);
      let betAmount = document.getElementById("betAmount").value;
      if (betAmount <= 0.001) {
        console.log("Not enough funds to enter the pot!");
      }
    }
  }

  const payout = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const betPortalContract = new ethers.Contract(contractAddress, contractABI, signer);

        let betCount = await betPortalContract.getBets();
        console.log("Retrieved total amount of bets...", betCount);
        let potSize = await betPortalContract.getPot();
        console.log("Retrieved pot size...", potSize.toString());

        /* Execute the actual payout from smart contract */

        console.log("Initiating payout now...");
        const payoutTxn = await betPortalContract.payOut({ gasLimit: 1000000 });
        console.log("Mining...", payoutTxn.hash);

        await payoutTxn.wait();
        console.log("Mined -- ", payoutTxn.hash);

        /* Double check if bet and pot got reset to 0*/
        betCount = await betPortalContract.getBets();
        console.log("Retrieved total amount of bets...", betCount);
        potSize = await betPortalContract.getPot();
        console.log("Retrieved pot size...", potSize.toString());

      } else {
        console.log("Ethereum object doesn't exist!");
      }
    } catch (error) {
      console.log(error);
    }
  }

  const getPot = async () => {
    try {
      const { ethereum } = window;

      if (ethereum) {
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const BetPortalContract = new ethers.Contract(contractAddress, contractABI, signer);

        let count = await BetPortalContract.getPot();
        console.log("Retrieved pot size...", count.toString()/1000000000000000000);
        document.getElementById("pot").innerHTML = count.toString()/1000000000000000000;
      } else {
        console.log("Ethereum object doesn't exist!");
      }
    } catch (error) {
      console.log(error);
    }
  }

  /*
  * This runs our function when the page loads.
  */
  useEffect(() => {
    checkIfWalletIsConnected();
  }, [])

  return (
    <div className="mainContainer">
      <div className="dataContainer">
        <div className="header">
          Bet on the price of ETH/USD!
        </div>

        <button className="betButton" onClick={bet} type="submit">
          Click here to make a bet in US Dollars.
        </button>

        <input type="text" placeholder="Guess (in USD)" id="guess"></input>
        <input type="text" placeholder="Bet Amount (in Rinkeby ETH)" id="betAmount"></input>

        {/*
        * If there is no currentAcount render this button
        */}
        {!currentAccount && (
          <button className="betButton" onClick={connectWallet}>
            Connect your Rinkeby wallet.
          </button>
        )}

        {/*
        * If owner of contract is using, render this button
        */}
        {currentAccount == 0xF8d61d4bf4b1E9bd35aDbDdf8561A5226A81F316 && (
          <button className="betButton" onClick={payout}>
            Pay out the pot.
          </button>
        )}

        <div className="potSize" onLoad={getPot()}>
          Current pot size: <span id="pot"></span> Ether
        </div>

      </div>
    </div>
  );
}

export default App